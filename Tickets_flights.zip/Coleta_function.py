from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd
import datetime

def coleta(html):
    html_source = html
    soup = BeautifulSoup(html_source, 'html.parser')
    voos = soup.find_all("leg-group")
    new_voos =[]
    for item in voos:
         new_voos.append(item.text)
    for i in range(0,(len(new_voos))):
         new_voos[i] = new_voos[i].replace("\n","")


    horarios = {}
    for i in range(0,(len(new_voos))):
        hora = []
        new_voos[i] = new_voos[i].replace("detalhes","")
        new_voos[i] = new_voos[i].replace("Menos voos"," ")
        new_voos[i] = new_voos[i].replace("\t", "")
        dp = []
        for k, c in enumerate(new_voos[i]):
            if c == ":":
                dp.append(k)
        for j in dp[1:]:
            hora.append(new_voos[i][j-2:j+3])
        horarios['Voo' + f' {i}'] = hora
    precos = soup.find_all("price-details")
    new_precos = []
    for item in precos:
         new_precos.append(item.text)
    for i in range(0,(len(new_precos))):
         new_precos[i] = new_precos[i].replace("\n","")
    precos2 = {}
    taxas = {}
    for n in range(0,len(new_precos)):
        dp2 = []
        dp3 = []
        dp4 = []
        prs = []
        txs = []
        for k, c in enumerate(new_precos[n]):
            if c == "$":
                dp2.append(k)
        for o, h in enumerate(new_precos[n]):
            if h == "T":
                dp3.append(o)
        for s, u in enumerate(new_precos[n]):
            if u == "P":
                dp4.append(s)
        prs.append(new_precos[n][int(dp2[0])+2:int(dp3[0])])
        txs.append(new_precos[n][int(dp2[1])+2:(int(dp4[1])-1)])
        precos2['Voo' + f' {n}'] = prs
        taxas['Voo' + f' {n}'] = txs

    logos = soup.find_all("airline-logo")
    cias = []
    for t in range(0,len(logos)):
        cias.append(logos[t].find("img")['alt'])
    cias = cias[0::2]



    dados = {}
    departures = []
    arrivals = []
    dia = []
    classe = []
    dp_hr = []
    ar_hr = []
    hours1 = []
    hours2 = []
    price = []
    taxes = []
    cia_aux = []
    paradas = []
    for i in range(0,len(new_voos)):
        departures.append(new_voos[i][0:3])
        dados['Departure'] = departures
        for r, w in enumerate(new_voos[i]):
            if w.isdigit():
                l = r
                break
        arrivals.append(new_voos[i][l-3:l])
        dados['Arrival'] = arrivals
        paradas.append('-'.join(new_voos[i][3:l-3][q:q + 3] for q in range(0, len(new_voos[i][3:l-3]), 3)))
        dados['Stops'] = paradas
        cia_aux.append(cias[i])
        dados['Cia'] = cia_aux
        dia.append(new_voos[i][l:new_voos[i].index(')')+1])
        dados['Day'] = dia
        for j, c in enumerate(new_voos[i][new_voos[i].index(":")+2:]):
            if c.isdigit():
                p = j + new_voos[i].index(":")+2
                break
        classe.append(new_voos[i][new_voos[i].index(":")+2:p])
        dados['Classe'] = classe
        price.append(precos2[list(precos2.keys())[i]])
        dados['Price'] = price
        taxes.append(taxas[list(taxas.keys())[i]])
        dados['Taxes'] = taxes
        hours1.append(horarios[list(horarios.keys())[i]][0::2])
        dados['Departure_hr'] = hours1
        hours2.append(horarios[list(horarios.keys())[i]][1::2])
        dados['Arrival_hr'] = hours2
        for key in list(dados.keys())[:-2]:
            for y in range(1,len(dados['Departure_hr'][i])):
                dados[key].append(dados[key][-1])

    flat_dep = []
    for sublist in dados['Departure_hr']:
        for item in sublist:
            flat_dep.append(item)

    dados['Departure_hr'] = flat_dep
    flat_arr = []
    for sublist in dados['Arrival_hr']:
        for item in sublist:
            flat_arr.append(item)
    dados['Arrival_hr'] = flat_arr

    flat_price = []
    for sublist in dados['Price']:
        for item in sublist:
            flat_price.append(item)
    dados['Price'] = flat_price

    flat_taxes = []
    for sublist in dados['Taxes']:
        for item in sublist:
            flat_taxes.append(item)
    dados['Taxes'] = flat_taxes

    b = pd.DataFrame(dados)
    return b