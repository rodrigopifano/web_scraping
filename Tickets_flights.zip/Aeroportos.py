import requests
from bs4 import BeautifulSoup


url_airports = "https://www.prokerala.com/travel/airports/brazil/"
aeroportos = requests.get(url_airports)
soup_aero = BeautifulSoup(aeroportos.text, "html.parser")
aeros = soup_aero.findAll("td", attrs={"class": "tc td-width-60"})
aeros_lista = []
for item in aeros:
    aeros_lista.append(item.text)

aeros_lista = [x for x in aeros_lista if len(x) == 3]
from itertools import product

aeros_lista = [p for p in product(aeros_lista, repeat=2)]
aeros_lista = [x for x in aeros_lista if x[0] != x[1]]

######
### Due to time of processing, since our goal is to learn how to collect the data, I've reduced the set of possible origins and destinations to a smaller one, including only the main airpoirts in the southeast
# aeros_lista_parcial = [x for x in aeros_lista if 'CNF' in x and 'GIG' in x or 'SDU' in x and 'CGH' in x or 'CNF' in x and 'SDU' in x or 'CNF' in x and 'GIG' in x or 'GIG' in x and 'GRU' in x or 'SDU' in x and 'GRU' in x]
