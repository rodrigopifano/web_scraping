import requests
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
import datetime
from Coleta_function import coleta
from Aeroportos import aeros_lista
import pyodbc
import os

url = "https://www.edestinos.com.br/?gclid=Cj0KCQiAwP3yBRCkARIsAABGiPoTVlJ8QX3eFxJMXEnaP33w9zSjKuHHf74cjzpJ6VYJJZt1eH93BYMaAgKdEALw_wcB"

from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')

server = '10.0.15.98,1438'
database = 'Passagens_ReP'
username = 'rodrigoap7'
password = 'mssql_pif+pass2'
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = cnxn.cursor()


######
### Due to time of processing, since our goal is to learn how to collect the data, I've reduced the set of possible origins and destinations to a smaller one, including only the main airpoirts in the southeast
# aeros_lista_parcial = [x for x in aeros_lista if 'CNF' in x and 'GIG' in x or 'SDU' in x and 'CGH' in x or 'CNF' in x and 'SDU' in x or 'CNF' in x and 'GIG' in x or 'GIG' in x and 'GRU' in x or 'SDU' in x and 'GRU' in x]
aeros_lista_parcial = [x for x in aeros_lista if 'CNF' in x and 'GIG' in x or 'SDU' in x and 'CGH' in x]




for aero in aeros_lista_parcial:
    driver = webdriver.Chrome(executable_path=os.getcwd()+"/chromedriver", options=chrome_options)
    driver.get(url)
    time.sleep(5)
    driver.set_window_size(1600, 1000)
    driver.find_elements_by_xpath('//*[@id="multiQsf"]/div[1]/div[3]/div/div[1]/a')[0].click()
    driver.find_elements_by_xpath('//*[@id="TripTypeOneway"]')[0].click()

    origem = driver.find_elements_by_xpath('//*[@id="departureOneway"]')
    origem[0].send_keys(aero[0])
    time.sleep(1)
    origem[0].send_keys(Keys.ENTER)

    destino = driver.find_elements_by_xpath('//*[@id="arrivalOneway"]')
    destino[0].send_keys(aero[1])
    time.sleep(1)
    destino[0].send_keys(Keys.ENTER)

    driver.find_elements_by_xpath('//*[@id="departureDateOneway"]')[0].send_keys(Keys.ENTER)
    time.sleep(1)
    driver.find_elements_by_xpath('//*[@id="multiQsfFlights"]/form/section[2]/div[2]/fieldset[2]/button')[0].click()
    time.sleep(1.5)
    handles = driver.window_handles
    try:
        driver.switch_to.window(handles[1])
    except:
        pass
    calendario = driver.find_element_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/esky-search-form/esky-oneway-roundtrip-form/form/section[2]/fieldset[2]/div/div[1]/div')
    calendario.click()
    time.sleep(1)
    dates1 = driver.find_element_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/esky-search-form/esky-oneway-roundtrip-form/form/section[2]/fieldset[2]/div/esky-multi-datepicker/div[1]/div[2]/esky-calendar/esky-calendar-month[1]')
    dates2 = driver.find_element_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/esky-search-form/esky-oneway-roundtrip-form/form/section[2]/fieldset[2]/div/esky-multi-datepicker/div[1]/div[2]/esky-calendar/esky-calendar-month[2]')
    time.sleep(0.5)
    dias1 = dates1.find_elements_by_tag_name('esky-calendar-day')
    dias2 = dates2.find_elements_by_tag_name('esky-calendar-day')
    time.sleep(0.25)
    vld_days1 = []
    for k in range(0, len(dias1)):
        vld_days1.append(dias1[k].find_elements_by_tag_name('esky-price'))
    vld_days2 = []
    for k in range(0, len(dias2)):
        vld_days2.append(dias2[k].find_elements_by_tag_name('esky-price'))
    vld_days = vld_days1 + vld_days2
    vld_days = [x for x in vld_days if x != []]
    for dia in range(0,len(vld_days)):
        try:
            time.sleep(0.25)
            base = pd.DataFrame(columns=["Departure", "Arrival", "Stops", "Cia", "Day", "Classe", "Price", "Taxes", "Departure_hr","Arrival_hr", "Consult_time"])
            vld_days[dia][0].click()
            driver.find_element_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/esky-search-form/esky-oneway-roundtrip-form/form/section[2]/fieldset[2]/div/esky-multi-datepicker/div[1]/div[3]/button').click()
            driver.find_element_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/esky-search-form/esky-oneway-roundtrip-form/form/section[2]/div/button').click()
            time.sleep(5)
            try:
                no_flights = [driver.find_element_by_tag_name('msg-box')]
            except:
                no_flights = []
            if no_flights != []:
                pass
            else:
                mais_voos = driver.find_elements_by_tag_name("leg-group")
                for item in mais_voos:
                    mais_voos2 = item.find_elements_by_tag_name("div")
                    if mais_voos2[-1].text[0:17] == 'Mostrar mais voos':
                        mais_voos2[-1].click()
                    else:
                        pass
                html = driver.page_source
                dados = coleta(html=html)
                dados['Consult_time'] = str(datetime.datetime.now())
                base = base.append(dados)
                n_pages = driver.find_elements_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/div/flights-list/div/div[1]/div/div/pagination/pagination-template/ol[1]')
                try:
                    pags = n_pages[0].find_elements_by_tag_name("li")
                    n_pags = int(pags[len(pags) - 2].text)
                except:
                    pass
                for p in range(1, n_pags):
                    try:
                        nxt_pg = driver.find_elements_by_xpath('/html/body/fsr-app/fsr-flights-search-result/fsr-qsf-layout/section/div/flights-list/div/div[1]/div/div/pagination/pagination-template/ol[1]/li[' + f'{len(pags)}]/a')
                        nxt_pg[0].click()
                    except:
                        pass
                    time.sleep(3)
                    mais_voos = driver.find_elements_by_tag_name("leg-group")
                    for item in mais_voos:
                        mais_voos2 = item.find_elements_by_tag_name("div")
                        if mais_voos2[-1].text[0:17] == 'Mostrar mais voos':
                            mais_voos2[-1].click()
                        else:
                            pass
                    html = driver.page_source
                    dados = coleta(html=html)
                    dados['Consult_time'] = str(datetime.datetime.now())
                    base = base.append(dados)
                colunas = str(tuple(list(base.columns))).replace("'", '')
                valores = str(list(base.to_records(index=False))).replace("[", "").replace("]", ";")
                stmt = 'INSERT INTO Passagens ' + f'{colunas} VALUES ' + f'{valores}'
                cursor.execute(stmt)
                cnxn.commit()
        except:
            pass
        calendario.click()
    driver.quit()

cursor.close()
cnxn.close()

