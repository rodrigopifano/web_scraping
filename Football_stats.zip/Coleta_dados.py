from bs4 import BeautifulSoup
import pandas as pd
import datetime
import requests
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import time
from itertools import chain
from selenium.webdriver.chrome.options import Options
# chrome_options = Options()
# chrome_options.add_argument("--headless")
# chrome_options.add_argument('--no-sandbox')
from selenium.webdriver.common.action_chains import ActionChains

#### Exemplos Bone ####

r  = requests.get("https://globoesporte.globo.com/")
html = r.text
soup = BeautifulSoup(html, 'lxml')
soup.findAll("title")


import pickle

def save_object(obj, filename):
    with open(filename, 'wb') as output:  # Overwrites any existing file.
        pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)


# How to open object
with open('dados_2019_completo.pk1', 'rb') as input:
    dados = pickle.load(input)




url = "https://www.sofascore.com/tournament/football/brazil/brasileiro-serie-a/325"

dados = {}
for r in range(0,38):
    print('r = '+f'{r}')
    driver = webdriver.Chrome(executable_path=os.getcwd() + "/Coleta_dados/chromedriver")
    time.sleep(1.5)
    driver.get(url)
    time.sleep(1.5)
    driver.set_window_size(1600, 1000)
    time.sleep(1.5)
    # driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div[2]/div/div/div/button')[0].click()
    #### Aqui entrará o loop de ano
    time.sleep(1.5)
    # years = driver.find_elements_by_xpath('/html/body/div[1]/main/div/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div[2]/div/div/div/ul/div/div[1]/li[2]')
    #
    # years[0].click()

    # Scrolling down Page
    time.sleep(1.5)
    driver.execute_script("window.scrollTo(0, 700)")
    time.sleep(1.5)
    # By round
    driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[1]/a[2]')[0].click()
    # Lista de Jogos da Rodada
    ## Loop de rodadas entra aqui
    # a = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[6]/div/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/button')[0].click()
    #
    # lista_rodadas = driver.find_element_by_css_selector('#downshift-76-menu')
    for j in range(0,r):
        time.sleep(1)
        driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[1]/div/div[1]/div[1]/div')[0].click()
        time.sleep(0.1)

    time.sleep(1)
    # Round = []
    rodada = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/button')
    # Round.append(rodada[0].text)
    ## Loop jogos da rodada entra aqui
    lista_rodada = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[1]/div/div[2]')
    time.sleep(0.5)
    jogos = lista_rodada[0].find_elements_by_tag_name('a')
    time.sleep(1.5)
    for i in range(1,len(jogos)):
        try:
            last_element = driver.find_element_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]')
            driver.execute_script("arguments[0].scrollIntoView(true);", last_element)
            jogos[i].click()
            time.sleep(6)
            times = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[1]/a')[0].text
            dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {'Times' : (times[0:(times.find("-")-1)],times[(times.find("-")+2):len(times)])}

            goals = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[1]/div[2]/div[2]/div[1]')[0].text
            dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']['Gols'] = (goals[0],goals[4])
            time.sleep(2)
            # Scroll down to see odds
            last_element = driver.find_element_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div/div[5]')
            driver.execute_script("arguments[0].scrollIntoView(true);", last_element)
            time.sleep(2)
            ##
            home_odds = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div/div[5]/div[2]/div/div[2]/div[1]/div/div/a/span[2]')[0].text
            Away_odds = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div/div[5]/div[2]/div/div[2]/div[3]/div/div/a/span[2]')[0].text
            dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']['Odds'] = (home_odds,Away_odds)
            time.sleep(2)
            ## Scroll up to find stats button
            last_element = driver.find_element_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[1]/div/div')
            driver.execute_script("arguments[0].scrollIntoView(true);", last_element)
            time.sleep(2)
            #Statistics
            driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[1]/div/div/a[2]')[0].click()
            time.sleep(2)
            first_stats = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div/div')[0].text
            # Scroll Down to see more stats
            time.sleep(2)
            last_element = driver.find_element_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div/div/div[7]/div[3]')
            driver.execute_script("arguments[0].scrollIntoView(true);", last_element)
            ## Colect more Stats
            time.sleep(2)
            more_stats = driver.find_elements_by_xpath('//*[@id="__next"]/main/div/div[2]/div[1]/div[1]/div[7]/div/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div[2]/div[2]/div/div[2]/div/div')[0].text
            # FIRST STATS LIST
            time.sleep(2)
            FS_S = []
            F_STATS = []
            for s, u in enumerate(first_stats):
               if u == "\n":
                  FS_S.append(s)
            aux = FS_S[2::3]
            FS_S2 = [[0]]
            FS_S2.append(aux)
            FS_S2 = list(chain.from_iterable(FS_S2))
            for k in range(0,(len(FS_S2)-1)):
                F_STATS.append(first_stats[FS_S2[k]:FS_S2[k+1]])
            F_STATS.append(first_stats[FS_S2[k+1]+1:len(first_stats)])
            F_STATS_aux = []
            for item in F_STATS:
                F_STATS_aux.append(item.replace("\n","_"))
            F_STATS_aux2 = []
            for item in F_STATS_aux:
                if item[0] == "_":
                    F_STATS_aux2.append(item[1:])
                else:
                    F_STATS_aux2.append(item)
            F_STATS = F_STATS_aux2
            # MORE STATS LIST
            MS_S = []
            M_STATS = []
            for s, u in enumerate(more_stats):
                if u == "\n":
                    MS_S.append(s)
            aux_m = MS_S[2::3]
            MS_S2 = [[0]]
            MS_S2.append(aux_m)
            MS_S2 = list(chain.from_iterable(MS_S2))
            for k in range(0,(len(MS_S2)-1)):
                M_STATS.append(more_stats[MS_S2[k]:MS_S2[k+1]])
            M_STATS.append(more_stats[MS_S2[k+1]+1:len(more_stats)])
            M_STATS_aux = []
            for item in M_STATS:
                M_STATS_aux.append(item.replace("\n", "_"))
            M_STATS_aux2 = []
            for item in M_STATS_aux:
                if item[0] == "_":
                    M_STATS_aux2.append(item[1:])
                else:
                    M_STATS_aux2.append(item)
            M_STATS = M_STATS_aux2
            ## Handling the stats for the home team
            F_STATS_dicio_home = {}
            for item in F_STATS:
                aux_nn = []
                for s, u in enumerate(item):
                    if u == "_":
                        aux_nn.append(s)
                nome = item[aux_nn[0]+1:aux_nn[1]]
                if 'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}' in F_STATS_dicio_home:
                    F_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][nome] = item[0:aux_nn[0]]
                else:
                    F_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {nome: item[0:aux_nn[0]]}

            M_STATS_dicio_home = {}
            for item in M_STATS:
                aux_nn = []
                for s, u in enumerate(item):
                    if u == "_":
                        aux_nn.append(s)
                nome = item[aux_nn[0] + 1:aux_nn[1]]
                if 'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}' in M_STATS_dicio_home:
                    M_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][nome] = item[0:aux_nn[0]]
                else:
                    M_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {nome: item[0:aux_nn[0]]}

            STATS_home = {**F_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'], **M_STATS_dicio_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']}
            STATS_home = {'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}': STATS_home}
            ## Handling the stats for the away team
            F_STATS_dicio_away = {}
            for item in F_STATS:
                aux_nn = []
                for s, u in enumerate(item):
                    if u == "_":
                        aux_nn.append(s)
                nome = item[aux_nn[0]+1:aux_nn[1]]
                if 'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}' in F_STATS_dicio_away:
                    F_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][nome] = item[aux_nn[1]+1:]
                else:
                    F_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {nome: item[aux_nn[1]+1:]}

            M_STATS_dicio_away = {}
            for item in M_STATS:
                aux_nn = []
                for s, u in enumerate(item):
                    if u == "_":
                        aux_nn.append(s)
                nome = item[aux_nn[0] + 1:aux_nn[1]]
                if 'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}' in M_STATS_dicio_away:
                    M_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][nome] = item[aux_nn[1]+1:]
                else:
                    M_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {nome: item[aux_nn[1]+1:]}

            STATS_away = {**F_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'], **M_STATS_dicio_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']}
            STATS_away = {'Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}' : STATS_away}
            ## Binding home and away stats in a single dictionary
            for key in STATS_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']:
                STATS_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][key] = STATS_home['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][key],STATS_away['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'][key]
            STATS = STATS_home
            ## Organizar todos os dados de um jogo só
            dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'] = {**dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'],**STATS['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}']}
            time.sleep(1.5)
            print('Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}')
            print(dados['Jogo_' + f'{i}' + '_' + f'{rodada[0].text[rodada[0].text.find(" ") + 1:len(rodada[0].text)]}'])
            save_object(dados, 'dados_2020.pk1')
            driver.execute_script("window.scrollTo(0, 900)")
        except:
            pass
    driver.quit()


## Conferindo e consertando erros de coleta




lista_times = []
for key in dados.keys():
    lista_times.append(dados[key]['Times'])

for key in dados.keys():
    if dados[key]['Times'] == ('Botafogo', 'Bahia'):
        print(key)
        print(dados[key])

del dados['Jogo_4_18']


for key in dados.keys():
    if key[len(key)-2:] == '_6':
        print(key)
        print(dados[key])


for key in dados.keys():
    print(len(dados[key].keys()))




import collections
print([item for item, count in collections.Counter(lista_times).items() if count > 1])


len(lista_times)

lista_keys = []
for key in teste.keys():
    lista_keys.append(key)


lista_jogos = []

for r in range(38,0,-1):
    for j in range(1,11):
        lista_jogos.append('Jogo_'+f'{j}'+'_'+f'{r}')


list_difference = [item for item in lista_jogos if item not in lista_keys]

import collections
print([item for item, count in collections.Counter(lista_jogos).items() if count > 1])


df_keys = pd.DataFrame(lista_keys)
df_jogos = pd.DataFrame(lista_jogos)


df_keys.merge(df_jogos)

list_difference2 = [item for item in lista_keys if item not in lista_jogos]





teste = dict(dados_provisorio,**dados)


teste['Jogo_3_7'] = teste['Jogo_11_7']
del teste['Jogo_11_7']


save_object(dados, 'dados_COMPLETO_2020.pk1')



for key in teste.keys():
    if teste[key]['Odds'] == ('', ''):
        print(key)
        print(teste[key])


for key in teste.keys():
    if key[len(key)-1:] == '8':
        print(key)
        print(teste[key])

for i in range(1,11):
    teste['Jogo_' + f'{i}' + '_8'] = dados['Jogo_' + f'{i}' + '_8']

for i in range(1,11):
    print(dados['Jogo_' + f'{i}' + '_8'])


