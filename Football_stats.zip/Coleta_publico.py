from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import time
import requests
from bs4 import BeautifulSoup


url = 'http://app.globoesporte.globo.com/futebol/publico-no-brasil/2019/brasileirao-serie-a/index.html'

driver = webdriver.Chrome(executable_path=os.getcwd() + "/Coleta_dados/chromedriver")
time.sleep(1.5)
driver.get(url)
time.sleep(1.5)
driver.set_window_size(1600, 1000)

html = driver.page_source
html_source = html
soup = BeautifulSoup(html_source, 'html.parser')




placar = soup.findAll("span", {"class": "placar"})
publico = soup.findAll("div", {"class": "valor-pagantes"})
publico = publico[20:]
ocupacao = soup.findAll("div", {"class": "pct-ocupacao"})
ocupacao = ocupacao[20:]


# Jogos

list_placar_aux = []
for item in placar:
    list_placar_aux.append(item.text)

list_placar = []
for item in list_placar_aux:
    list_placar.append(item.replace("\n",""))

# Publico

list_publico_aux = []
for item in publico:
    list_publico_aux.append(item.text)

list_publico = []
import re
for item in list_publico_aux:
    list_publico.append(re.sub("[^0-9]", "", item))

# Ocupação

list_ocupacao_aux = []
for item in ocupacao:
    list_ocupacao_aux.append(item.text)

list_ocupacao = []
for item in list_ocupacao_aux:
    list_ocupacao.append(re.sub("[^0-9]", "", item))


dados_publico = {}

for i in range(0,len(list_placar)):
    dados_publico['Jogo_' + f'{i+1}'] = {'Times' : (list_placar[i][0:3],list_placar[i][len(list_placar[i])-3:])}
    dados_publico['Jogo_' + f'{i+1}']['Publico'] = list_publico[i]
    dados_publico['Jogo_' + f'{i+1}']['Ocupacao'] = list_ocupacao[i]

save_object(dados_publico, 'dados_Publico_2019.pk1')

